<html>

<head>
<link rel="stylesheet" href="bin/lib/cmd.css" />
<link rel="stylesheet" href="theme/lesser-dark.css" />

<title>Live Editor</title>
<script src="bin/lib/cmd.js"></script>
<script src="mode/fortran/fortran.js"></script>
<script src="mode/javascript/javascript.js"></script>
<script src="extras/matchbrackets.js"></script>
<script src="extras/closebrackets.js"></script>
<script src="extras/closetag.js"></script>
<script src="mode/php/php.js"></script>
<script src="mode/css/css.js"></script>
<script src="mode/sql/sql.js"></script>
<script src="mode/vb/vb.js"></script>
<script src="mode/vbscript/vbscript.js"></script>
<script src="mode/htmlmixed/htmlmixed.js"></script>
<script src="mode/python/python.js"></script>
<script src="extras/active-line.js"></script>
<script src="mode/xml/xml.js"></script>

<style>
body {
	background-color: #000;
}
h1 {
	color:#CCC;
}
table,td,th {
	color: #CCC;
	font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
	border-top-style: solid;
	border-right-style: solid;
	border-bottom-style: solid;
	border-left-style: solid;
	border-top-width: 1px;
	border-right-width: 1px;
	border-bottom-width: 1px;
	border-left-width: 1px;
}
table {
	width:100%;
	height:100%;
	display:block;
	position:fixed;
}
a:link {
	color: #999;
	text-decoration: none;
}
a:hover {
	color: #CCC;
	text-decoration: underline;
}
a:visited {
	text-decoration: none;
	color: #999;
}
a:active {
	text-decoration: none;
}
textarea {
	width:100%;
	height:100%;
	display:block;
}
.project_header {
	background-color:#999;
	width:98%;
	padding:5px;
	display:block;
	cursor:pointer;
	color:white;
}
button {
	background:#999;
	padding:10px;
	border:2px solid #CCC;
	color:white;
}
.sub_dir {
	cursor:pointer;
}
select {
	padding:10px;
	background:#999;
	color:white;
	border:2px solid #CCC;
	-webkit-appearence:none !important;
	-moz-appearence:none !important;
	appearence:none !important;
}

iframe {
	width:100%;
	height:100%;
	display:block;
	background:white;
	color:black;
	overflow:scroll;
	float:right;
}
</style>
</head>

<body>
<div><h1>Live Editor By CodeStudio</h1></div>
<select class='form-controls' id="lang">
<option value="htmlmixed">HTML</option>
<option value="css">CSS</option>
<option value="php">PHP</option>
<option value="javascript">JavaScript</option>
<option value="vb">VB</option>
<option value="python">Python</option>
<option value="xml">XML</option>
<option value="sql">SQL</option>
<option value="vbscript">VBScript</option>
<option value="fortran">Fortran</option>
</select>
<div>
<button onclick="runCode();">Runcode</button>
<table>
  <tr>
    <td onkeyup='runCode();' width="604" style="overflow:scroll;" height="100%"><textarea name="code" id="code"></textarea></td>
    <td width="604" height="480">
    <iframe id="iframe" width="100%" height="100%" align="right"></iframe>
    </td>
  </tr>
</table>
</div>
<script>

  var editor = CodeMirror.fromTextArea(document.getElementById("code"), {
    lineNumbers: true,
    styleActiveLine: true,
    matchBrackets: true,
	autoCloseBrackets: true,
	autoCloseTags: true,
	theme : "lesser-dark",
	wordWrap:true,
	lineWrapping: !0,
 });
  document.getElementById('lang').onchange = function() {
	 var lang = document.getElementById('lang').value;
	 editor.setOption('mode',lang);
 }
 
 function runCode(){
	var content = editor.getValue();
	var iframe = document.getElementById("iframe");
	iframe = (iframe.contentWindow) ? iframe.contentWindow : (iframe.contentDocument.document) ? iframe.contentDocument.document : iframe.contentDocument;
	iframe.document.open();
	iframe.document.write(content);
	iframe.document.close();
	return false;
	
}

runCode();

 editor.blur = function() {
	 runCode();
 }
</script>
</body>
</html>