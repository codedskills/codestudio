<html>
<head>
<?php 
require('config.php');
?>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Welcome CodeStudio</title>
<link rel="stylesheet" href="theme/bootstrap.min.css" />
<style>
a {
	width:95%;
	padding:5px;
	display:block;
	color:blue;
}
</style>
</script>
<script>
function create_dir() {
	var dir_name = document.getElementById('dir_name').value;
	var hr = new XMLHttpRequest();
	hr.open('POST','create_dir.php');
	hr.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
	hr.onreadystatechange = function() {
		if(hr.readyState == 4 && hr.status == 200) {
		var stat = hr.responseText;
		var st = document.getElementById('stat');
		st.innerHTML = stat;
		}
	}
	var file_type = document.getElementById('file_type').value;
	hr.send('folder='+dir_name+"&file_type="+file_type);
	window.location = "editor.php?dir="+dir_name;
}

function load_default() {
	var hr = new XMLHttpRequest();
	var folder = '<?php echo get_ini_dir(); ?>';
	hr.open('POST','atom_manager.php',true);
	hr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
	hr.onreadystatechange = function() {
		if(hr.readyState == 4 && hr.status == 200) {
			var edit_window = document.getElementById('edit_window');
			if(hr.responseText == "No Projects Avalible<br><button class='btn btn-primary' data-toggle='modal' data-target='#new_page'>Create One</button>") {
				edit_window.innerHTML = hr.responseText;
			}else{
			var d = JSON.parse(hr.responseText);
			edit_window.innerHTML = "Select the Project you want to open -: <br>";
			for(var o in d) {
				edit_window.innerHTML += '<br><a href="editor.php?dir='+d[o].src+'">'+d[o].name+'</a>';
			}
			}
		}
	}
	edit_window.innerHTML += "Searching for directories";
	hr.send('folder='+folder);
}
</script>
<style type="text/css">
body {
	background-color: #000;
}
body,td,th {
	color: #CCC;
}

div {
	color:black;
	
}
a {
	text-decoration: none;
	padding:10px;
	border:1px solid white;
	color:white;
}

.dialog-box {
	width:450px;
	height:150px;
	display:block;
	border:1px solid #999;
}
button {
	padding:10px;
	background:#999;
	color:white;
	font-weight:bold;
	border:1px solid #FFF;
}
button:hover {
	opacity:0.9;
}

select {
	padding:10px;
	border-radius:5%;
	color:white;
	background:#999;
}

select > option {
	padding:10px;
	pointer:cursor;
}

input[type='text'] {
	width:95%;
	display:block;
	padding:5px;
	background:darkgrey;
	color:white;
	border:1px solid #999;
	padding:5px;
	border-radius:15%;
}

.modal-header {
	background-color:rgba(0,0,0,.5);
	color:white;
}
.modal-body {
	background-color:rgba(0,0,0,.6);
	color:white;
}
.modal-footer {
	background-color:rgba(0,0,0,.5);
	color:white;
}

a:hover {
	color:blue;
	border-color:blue;
}
</style>
</head>

<body>
<center><h1>Welcome to codeStudio</h1>


  <div id="new_page" class="modal fade" tabindex="-1" aria-labelledby="new_page_label">
	<div class="modal-dialog" role="document">
		<div class="modal-content">
			<div class="modal-header">
				     <button type="button" class="close" data-dismiss="modal">&times;</button>
					 <h4 class="modal-title" id="edit_page_label">Create new site</h4>
			</div>
			<div id="stat" class="modal-body">
			
				<label align="left">Enter Project Name -:</label><br>
				<input id="dir_name" type="text" class="form-controls"><br>
				<br>
				<select class='form-controls' id="file_type">
				<option value='plain'>Select project type</option>
				<option value='myGL'>MYGL project</option>
				<option value='javascript'>Javascript</option>
				<option value='PHP'>PHP</option>
				<option value='HTML'>HTML Application</option>
				<option value='CSS'>CSS Stylesheet</option>
				</select>
			</div>
			<div class="modal-footer">
				<button align="right" class="btn btn-primary" onclick="create_dir();">Create</button>
			</div>
		</div>
	</div>
  </div>
  
  
  
  <div id="edit_toggle" class="modal fade" tabindex="-1" aria-labelledby="edit_page_label">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title" id="edit_page_label">Edit existing sites</h4>
        </div>
        <div id="edit_window" class="modal-body">
        </div>
      </div>
    </div>
  </div>
  <button class='btn btn-primary btn-lg' data-toggle="modal" data-target="#new_page">Create New Project</button>
  <p></p>
    <button class="btn btn-primary btn-lg" onclick="load_default();" data-toggle="modal" data-target="#edit_toggle">
    Edit Existing project
	</button>

</center>
	<script src="lib/jquery.min.js"></script>
	<script src="lib/modal.js"></script>
	<script src="lib/transition.js"></script>
	<script src="lib/collapse.js"></script>
</body>
</html>
