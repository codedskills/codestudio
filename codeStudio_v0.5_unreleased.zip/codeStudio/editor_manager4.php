<?php 
 $file_name = $_GET['file_name'];
 $folder = $_GET['dir_name'].'/';
 require('config.php');
 $project = get_ini_dir();
 $ext = $_GET['file_type'];
 $file_dir = $project.$folder.$file_name.$ext;
 $file = fopen($file_dir,'w');
	 if(fwrite($file,'<!-- .codeStudio -->')){
	 $status = "Created successfull";
	 } else {
	 $status = "Error";
	 }
 fclose($file);
 echo $status;
?>