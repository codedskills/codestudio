<?php 


function get_ini_dir() {
	$conf = parse_ini_file("conf/conf.ini");
	$prf_dir = $conf['project_dir'];
	return $prf_dir;
}
$project_dir = get_ini_dir();
?>