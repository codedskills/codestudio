<?php
 header('Content-Type:application/json');
 require('config.php');
 $folder = $_POST['folder'];
 $jsonData = '{';
 $project = get_ini_dir();
 $dir = $project.'/'.$folder;
 $dirHandle = opendir($dir);

 $i = 0;
 while($file = readdir($dirHandle)) {
	 if($file != '.' && $file != '..'){
            $i++;
            $src = $file;
            $jsonData .= '"folder' . $i . '":{ "num" : "' . $i . '","src":"' . $src . '", "name":"' . $file . '" },';
	 }
 }
 closedir();
 $jsonData = chop($jsonData,',');
 $jsonData .= '}';
 echo $jsonData;
?>