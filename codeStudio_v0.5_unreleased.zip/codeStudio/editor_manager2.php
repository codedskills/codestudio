<?php
	$file_name = $_POST['file'];
	require('config.php');
	$project = get_ini_dir();
	$project_name = $_POST['file_name'];
	$file = $project.'/'.$project_name.'/'.$file_name;
	if($fileHandle = file_get_contents($file)) {
	echo $fileHandle;
	}
?>