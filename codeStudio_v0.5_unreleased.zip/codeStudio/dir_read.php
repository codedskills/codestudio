<?php 
class RD {
	public function dir_read( $dir ) {
		$this->directory_children( $dir );
	}
	
	public function directory_children ( $dir ) {

		$cleanpath = realpath( $dir ). DIRECTORY_SEPARATOR;
		$scanDir = scandir($cleanpath);
		echo "<ul>";
		foreach($scanDir as $file) {
			if($file == '.' || $file == '..') {
				continue;
			}
			if(is_dir($dir.'/'.$file) && is_readable($dir.'/'.$file)) {
				$file_typ = '?dir='.$file;
				$this->directory_children($dir.'/'.$file);
				echo "<li><a href='editor.php$file_typ'>$file</a></li>";
			}else{
				$file_typ = '?fname='.$dir.'/'.$file;
				echo "<li><a href='editor.php$file_typ'>$file</a></li>";
			}
		}
		echo "</ul>";
	}		
}

$rd = new RD();
echo $rd->dir_read('projects/');

?>