<?php
  require('config.php');
  $file_name = $_GET['file_name'];
  $file_content = $_GET['file_content'];
  $project_dir = $_GET['dir'].'/';
  $project = get_ini_dir();
  $roast = $project.'/'.$project_dir.$file_name;
  $file = fopen($roast,'w');
  $fileHandle = fwrite($file,$file_content);
  if($fileHandle){
	  $status = "Saved Succesfull";
  }else{
	  $status = "Error Saving File";
  }
  echo $status;
	
?>