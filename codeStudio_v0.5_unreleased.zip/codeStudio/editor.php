

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
<title>Editor <?php echo $_GET['dir']; ?></title>
<link rel="stylesheet" href="theme/lesser-dark.css" />
<link rel="stylesheet" href="bin/lib/cmd.css" />
<script src="bin/lib/cmd.js"></script>
<script src="mode/fortran/fortran.js"></script>
<script src="mode/javascript/javascript.js"></script>
<script src="extras/matchbrackets.js"></script>
<script src="extras/closebrackets.js"></script>
<script src="extras/closetag.js"></script>
<script src="mode/php/php.js"></script>
<script src="mode/css/css.js"></script>
<script src="mode/sql/sql.js"></script>
<script src="mode/vb/vb.js"></script>
<script src="mode/vbscript/vbscript.js"></script>
<script src="mode/htmlmixed/htmlmixed.js"></script>
<script src="mode/python/python.js"></script>
<script src="extras/active-line.js"></script>
<script src="mode/xml/xml.js"></script>
<link rel="stylesheet" href="theme/bootstrap.min.css" />
<style type="text/css">
body {
	background-color: #000;
}
h1 {
	color:#CCC;
}
table,td,th {
	color: #CCC;
	font-family: "Trebuchet MS", Arial, Helvetica, sans-serif;
	border-top-style: solid;
	border-right-style: solid;
	border-bottom-style: solid;
	border-left-style: solid;
	border-top-width: 1px;
	border-right-width: 1px;
	border-bottom-width: 1px;
	border-left-width: 1px;
}
a:link {
	color: #999;
	text-decoration: none;
}
a:hover {
	color: #CCC;
	text-decoration: underline;
}
a:visited {
	text-decoration: none;
	color: #999;
}
a:active {
	text-decoration: none;
}
textarea {
	width:100%;
	height:100%;
	display:block;
}
.project_header {
	background-color:#999;
	width:98%;
	padding:5px;
	display:block;
	cursor:pointer;
	color:white;
}
button {
	background:#999;
	padding:10px;
	border:2px solid #CCC;
	color:white;
}
.sub_dir {
	cursor:pointer;
}
select {
	padding:10px;
	background:#999;
	color:white;
	border:2px solid #CCC;
	-webkit-appearence:none !important;
	-moz-appearence:none !important;
	appearence:none !important;
}

option:hover {
	padding:5px;
}

select {
	padding:10px;
	border-radius:5%;
	color:white;
	background:#999;
}

select > option {
	padding:10px;
	pointer:cursor;
}

input[type='text'] {
	width:95%;
	display:block;
	padding:5px;
	background:darkgrey;
	color:white;
	border:1px solid #999;
	padding:5px;
}

.modal-header {
	background-color:rgba(0,0,0,.5);
	color:white;
}
.modal-body {
	background-color:rgba(0,0,0,.6);
	color:white;
}
.modal-footer {
	background-color:rgba(0,0,0,.5);
	color:white;
}

a:hover {
	color:blue;
	border-color:blue;
}
</style>
<script>
function json_manager_encoded() {
	var inbox = document.getElementById('inbox');
	var hr = new XMLHttpRequest();
	var folder = "<?php echo $_GET['dir'] ?>";
	hr.open('POST','editor_manager1.php',true);
	hr.setRequestHeader('Content-Type','application/x-www-form-urlencoded');

	hr.onreadystatechange = function() {
		if(hr.readyState == 4 && hr.status == 200) {
			var d = JSON.parse(hr.responseText);
			inbox.innerHTML = "";
			for(var o in d) {
					inbox.innerHTML += "<div class='sub_dir' onclick='putin(\""+d[o].src+"\")'>"+d[o].name+"</div>";
			}

		}
	}
	inbox.innerHTML="waiting...";
	hr.send('folder='+folder);
}
</script>
</head>
<body onload = "json_manager_encoded();">


  <div id="save_toggle" class="modal fade" tabindex="-1" aria-labelledby="save_page_label">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title" id="save_page_label">Save current page</h4>
        </div>
        <div class="modal-body">
		<label>Due to condition please enter the name of file as to be Compiled below -:</label><br>
		<input type="text" id="save_file">
        </div>
		<div class='modal-footer'>
			<b id="save_st" class='warning'>Warning Compiled file will result the code in single line are you sure you want to compiled</b><br>
			<button onclick="saveFile();" class='btn btn-success'>Save Changes</button>
			<button data-dismiss="modal" class='btn btn-default'>Cancel</button>
		</div>
      </div>
    </div>
  </div>
  
  
  
  <div id="new_toggle" class="modal fade" tabindex="-1" aria-labelledby="new_page_label">
    <div class="modal-dialog" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <button type="button" class="close" data-dismiss="modal">&times;</button>
          <h4 class="modal-title" id="new_page_label">Create New page</h4>
        </div>
        <div id="new_modal" class="modal-body">
		<label>enter the name of file as to be saved below -:</label><br>
		<input type="text" id="new_file">
		<br>
		<select name='file_type' id='file_type'>
		<option value='.html'>HTML File</option>
		<option value='.js'>JavaScript File</option>
		<option value='.css'>Cascading Stylesheet File</option>
		<option value='.php'>PHP File</option>
		</select>
        </div>
		<div class='modal-footer'>
			<span id="new_st"></span>
			<button onclick="newFile();" class='btn btn-success'>Create</button>
		</div>
      </div>
    </div>
  </div>





<h1>Editor - CodeStudio</h1>





<button class='btn btn-primary' data-toggle="modal" data-target="#save_toggle">Save File</button> <button class='btn btn-primary' data-toggle="modal" data-target="#new_toggle" >New File</button> <select class='form-controls' id="lang">
<option value="htmlmixed">HTML</option>
<option value="css">CSS</option>
<option value="php">PHP</option>
<option value="javascript">JavaScript</option>
<option value="vb">VB</option>
<option value="python">Python</option>
<option value="xml">XML</option>
<option value="sql">SQL</option>
<option value="vbscript">VBScript</option>
<option value="fortran">Fortran</option>
</select>



<hr />



<table width="100%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="22%" height="402" align="left" valign="top"><div id="inbox"></div></td>
    <td>
    <textarea name="code" cols="120" rows="50" id="code"></textarea>
    </td>
  </tr>
</table>






<div align="center"><a href="https://codedSkills.wordpress.com">Copyright(c) codedSkills</a></div>

	<script src="lib/jquery.min.js"></script>
	<script src="lib/modal.js"></script>
	<script src="lib/transition.js"></script>
	<script src="lib/collapse.js"></script>


<script>
  var editor = CodeMirror.fromTextArea(document.getElementById("code"), {
    lineNumbers: true,
    styleActiveLine: true,
    matchBrackets: true,
	autoCloseBrackets: true,
	autoCloseTags: true,
	theme : "lesser-dark",
 });
 document.getElementById('lang').onchange = function() {
	 var lang = document.getElementById('lang').value;
	 editor.setOption('mode',lang);
 }
  
  	function putin(handler) {
		var code = document.getElementById('code');
		var de = new XMLHttpRequest();
		de.open('POST','editor_manager2.php',true);
		de.setRequestHeader('Content-Type','application/x-www-form-urlencoded');
		de.onreadystatechange = function() {
			if(de.readyState == 4 && de.status == 200) {
				var data = de.responseText;
				editor.setValue(data);
			}
		}
		var folder = '<?php echo $_GET['dir']; ?>';
		de.send('file='+handler+'&file_name='+folder);
	}
	function saveFile() {
		var status_box = document.getElementById('save_st');
		var file_name = document.getElementById('save_file').value;
		var folder = '<?php echo $_GET['dir']; ?>';
		var sa = new XMLHttpRequest();
		sa.open("GET","editor_manager3.php?file_name="+file_name+"&file_content="+editor.getValue()+"&dir="+folder,true);
		sa.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
		sa.onreadystatechange = function() {
			if(sa.readyState == 4 && sa.status == 200) {
				var respond = sa.responseText;
				status_box.innerHTML = respond;
			}
		}
		
		var editor_data = editor.getValue();
		status_box.innerHTML = "Saving...";
		sa.send("?file_name="+file_name+"&file_content="+editor_data+"&dir="+folder);
	}
	function newFile() {
		var file_name = document.getElementById('new_file').value;
		var folder = "<?php echo $_GET['dir']; ?>";
		var sa = new XMLHttpRequest();
		var file_type = document.getElementById('file_type').value;
		sa.open("GET","editor_manager4.php?file_name="+file_name+"&dir_name="+folder+"&file_type="+file_type,true);
		sa.setRequestHeader("Content-Type","application/x-www-form-urlencoded");
		sa.onreadystatechange = function() {
			if(sa.readyState == 4 && sa.status == 200) {
				var respond = sa.responseText;
				var status = document.getElementById('new_st');
				status.innerHTML = respond;
			}
		}
		sa.send("?file_name="+file_name+"&dir_name="+folder+"&file_type="+file_type);
		
		json_manager_encoded();
	}
</script>
</body>
</html>