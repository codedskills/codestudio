<?php 
 header('Content-Type:application/json');
 require('config.php');
 $jsonData = '{';
 $dir = get_ini_dir().'/';
 $dirHandle = opendir($dir);

 $i = 0;
 while($file = readdir($dirHandle)) {
	 if($file != '.' && $file != '..'){
            $i++;
            $src = $file;
            $jsonData .= '"folder' . $i . '":{ "num" : "' . $i . '","src":"' . $src . '", "name":"' . $file . '" },';
	 }
 }
 closedir();
 $jsonData = chop($jsonData,',');
 
 $jsonData .= '}';
 if($jsonData == '{}') {
	$jsonData = "No Projects Avalible<br><button class='btn btn-primary' data-toggle='modal' data-target='#new_page'>Create One</button>";
 }
 echo $jsonData;
?>