<?php
header('Content-Type: application/json');
if(isset($_POST['folder'])){
	require('config.php');
	$folder = $_POST['folder'].'/';
	$project_dir = get_ini_dir();
	$project_dir = $project_dir.'/';
	if(mkdir($project_dir.$folder)) {
		mkdir($project_dir.$folder.'.codeStudio');
		$file = fopen($project_dir.$folder.'.codeStudio/.details', 'w');
		fwrite($file,'Project type : '.$_POST['file_type']);
	$response_msg = "<span class='success'>Succesfully created a folder<span><br>Redirecting you to editor";
	}else{
		$response_msg = "Error : Type Unkown";
	}
echo $response_msg;

}
?>